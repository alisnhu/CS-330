///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}



/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{

	bool bReturn = false;
	//loading textures
	bReturn = CreateGLTexture("textures/keyboard.jpg", "keyboard");
	bReturn = CreateGLTexture("textures/screen.png", "screen");
	bReturn = CreateGLTexture("textures/rubber.png", "rubber");
	bReturn = CreateGLTexture("textures/plastic.jpg", "plastic");
	bReturn = CreateGLTexture("textures/wood.jpg", "wood");
	bReturn = CreateGLTexture("textures/cigarette.png", "cigarette");

	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/




	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess); 
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::DefineObjectMaterials()
{
	/*** STUDENTS - add the code BELOW for defining object materials. ***/
	/*** There is no limit to the number of object materials that can ***/
	/*** be defined. Refer to the code in the OpenGL Sample for help  ***/

	//defining materal of all shapes
	/************************* Table **************************/
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);  // black
	woodMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f); // less reflection
	woodMaterial.shininess = 2.0;                            // Mate surface less 
	woodMaterial.tag = "blackboard";
	m_objectMaterials.push_back(woodMaterial);

	/************************* Laptop **************************/
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.diffuseColor = glm::vec3(0.2f, 0.15f, 0.1f);  // Warm dark gray
	plasticMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);  // Low reflection
	plasticMaterial.shininess = 1.0;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	OBJECT_MATERIAL blackPlasticMaterial;
	blackPlasticMaterial.diffuseColor = glm::vec3(0.05f, 0.05f, 0.05f);  // Very dark gray
	blackPlasticMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);    // Low reflection
	blackPlasticMaterial.shininess = 2.0f;                               // Slightly shiny
	blackPlasticMaterial.tag = "blackPlastic";
	m_objectMaterials.push_back(blackPlasticMaterial);

	OBJECT_MATERIAL nonReflectiveMaterial;
	nonReflectiveMaterial.diffuseColor = glm::vec3(0.1f, 0.08f, 0.06f);  // Very dark warm gray
	nonReflectiveMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);   // No reflection
	nonReflectiveMaterial.shininess = 0.001;
	nonReflectiveMaterial.tag = "non_reflective";
	m_objectMaterials.push_back(nonReflectiveMaterial);

	OBJECT_MATERIAL mattePlastic;
	mattePlastic.diffuseColor = glm::vec3(0.12f, 0.1f, 0.08f);  // Dark warm gray
	mattePlastic.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);  // Very low reflection
	mattePlastic.shininess = 0.5;
	mattePlastic.tag = "mattePlastic";
	m_objectMaterials.push_back(mattePlastic);

	OBJECT_MATERIAL metallicBlack;
	metallicBlack.diffuseColor = glm::vec3(0.1f, 0.1f, 0.1f);   // Very dark gray
	metallicBlack.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);  // Moderate reflection
	metallicBlack.shininess = 5.0;
	metallicBlack.tag = "metallicBlack";
	m_objectMaterials.push_back(metallicBlack);

	OBJECT_MATERIAL mirrorBlack;
	mirrorBlack.diffuseColor = glm::vec3(0.08f, 0.08f, 0.07f);  // Very dark warm gray
	mirrorBlack.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);    // Moderate reflection
	mirrorBlack.shininess = 8.0;
	mirrorBlack.tag = "mirrorBlack";
	m_objectMaterials.push_back(mirrorBlack);

	OBJECT_MATERIAL rubberMaterial;
	rubberMaterial.diffuseColor = glm::vec3(0.2f, 0.05f, 0.05f);  // Dark red
	rubberMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);   // Low reflection
	rubberMaterial.shininess = 1.0;
	rubberMaterial.tag = "rubber";
	m_objectMaterials.push_back(rubberMaterial);

	OBJECT_MATERIAL screenMaterial;
	screenMaterial.diffuseColor = glm::vec3(0.1f, 0.1f, 0.1f);    // Dark gray
	screenMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);   // Low reflection
	screenMaterial.shininess = 16.0f;
	screenMaterial.tag = "screen";
	m_objectMaterials.push_back(screenMaterial);

	/************ Glass material ***********************/
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.4, 0.3, 0.2);      // Warm brown
	glassMaterial.specularColor = glm::vec3(0.1, 0.1, 0.1);     // Low reflection
	glassMaterial.shininess = 1.0f;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL whiskeyMaterial;
	whiskeyMaterial.diffuseColor = glm::vec3(0.4, 0.2, 0.1);     // Dark amber
	whiskeyMaterial.specularColor = glm::vec3(0.8, 0.5, 0.3);    // Warm reflection
	whiskeyMaterial.shininess = 56.0f;
	whiskeyMaterial.tag = "whiskey";
	m_objectMaterials.push_back(whiskeyMaterial);

	OBJECT_MATERIAL iceMaterial;
	iceMaterial.diffuseColor = glm::vec3(0.3, 0.3, 0.3);         // Dark gray
	iceMaterial.specularColor = glm::vec3(0.7, 0.7, 0.7);        // High reflection
	iceMaterial.shininess = 64.0f;
	iceMaterial.tag = "iceCube";
	m_objectMaterials.push_back(iceMaterial);

	OBJECT_MATERIAL capMaterial;
	capMaterial.diffuseColor = glm::vec3(0.3, 0.15, 0.15);       // Dark red
	capMaterial.specularColor = glm::vec3(0.4, 0.4, 0.4);        // Moderate reflection
	capMaterial.shininess = 32.0f;
	capMaterial.tag = "capMaterial";
	m_objectMaterials.push_back(capMaterial);

	/************ Book material ***********************/
	OBJECT_MATERIAL paperMaterial;
	paperMaterial.diffuseColor = glm::vec3(0.3f, 0.28f, 0.25f);  // Warm gray
	paperMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);   // Low reflection
	paperMaterial.shininess = 1.0f;
	paperMaterial.tag = "paper";
	m_objectMaterials.push_back(paperMaterial);

	OBJECT_MATERIAL bookCoverMaterial;
	bookCoverMaterial.diffuseColor = glm::vec3(0.15f, 0.12f, 0.1f);  // Dark warm gray
	bookCoverMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);   // Low reflection
	bookCoverMaterial.shininess = 2.0f;
	bookCoverMaterial.tag = "bookCover";
	m_objectMaterials.push_back(bookCoverMaterial);

	/************ Cigarette material ***********************/
	OBJECT_MATERIAL ashMaterial;
	ashMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);      // Dark gray
	ashMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);     // Low reflection
	ashMaterial.shininess = 1.0f;
	ashMaterial.tag = "ash";
	m_objectMaterials.push_back(ashMaterial);

	OBJECT_MATERIAL filterMaterial;
	filterMaterial.diffuseColor = glm::vec3(0.4, 0.3, 0.2);      // Warm brown
	filterMaterial.specularColor = glm::vec3(0.1, 0.1, 0.1);     // Low reflection
	filterMaterial.shininess = 1.0f;
	filterMaterial.tag = "filter";
	m_objectMaterials.push_back(filterMaterial);

	OBJECT_MATERIAL cigarettePaper;
	cigarettePaper.diffuseColor = glm::vec3(0.3f, 0.28f, 0.25f); // Light warm gray
	cigarettePaper.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);  // Low reflection
	cigarettePaper.shininess = 1.0;
	cigarettePaper.tag = "cigarettePaper";
	m_objectMaterials.push_back(cigarettePaper);

	/************ Ashtray material ***********************/
	OBJECT_MATERIAL ashTrayMaterial;
	ashTrayMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);  // Dark gray
	ashTrayMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);    // Low reflection
	ashTrayMaterial.shininess = 10.0;
	ashTrayMaterial.tag = "ashTray";
	m_objectMaterials.push_back(ashTrayMaterial);

	/************ Matches material ***********************/
	OBJECT_MATERIAL yellowpaperMaterial;
	yellowpaperMaterial.diffuseColor = glm::vec3(0.4, 0.35, 0.3);   // Warm light brown
	yellowpaperMaterial.specularColor = glm::vec3(0.1, 0.1, 0.1);   // Low reflection
	yellowpaperMaterial.shininess = 1.0f;
	yellowpaperMaterial.tag = "yellowPaper";
	m_objectMaterials.push_back(yellowpaperMaterial);
	

}



void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/

	/*-------------Laptop Screen Light -------------------------------------------------*/

	
	m_pShaderManager->setVec3Value("directionalLight.direction", 0.0f, -1.0f, 5.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.2f, 0.16f, 0.12f);   
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.6f, 0.5f, 0.4f);    
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.3f, 0.3f, 0.3f);   
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(22.5f, 5.0f, -35.0f)); 
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.2f, 0.16f, 0.12f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.8f, 0.7f, 0.6f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.4f, 0.4f, 0.4f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(22.5f, 5.0f, -35.0f));  
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.2f, 0.16f, 0.12f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.8f, 0.7f, 0.6f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.4f, 0.4f, 0.4f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	/*
	m_pShaderManager->setVec3Value("pointLights[0].position", 21.0f, 5.0f, -35.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.05f, 0.04f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.4f, 0.35f, 0.3f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	m_pShaderManager->setVec3Value("pointLights[3].position", 21.0f, 5.0f, -35.0f);
	m_pShaderManager->setVec3Value("pointLights[3].ambient", 0.05f, 0.04f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[3].diffuse", 0.4f, 0.35f, 0.3f);
	m_pShaderManager->setVec3Value("pointLights[3].specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[3].bActive", true);


	m_pShaderManager->setVec3Value("pointLights[1].position", 24.0f, 5.0f, -35.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.05f, 0.04f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.4f, 0.35f, 0.3f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[2].position", 24.0f, 5.0f, -35.0f);
	m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.05f, 0.04f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.4f, 0.35f, 0.3f);
	m_pShaderManager->setVec3Value("pointLights[2].specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[4].position", 24.0f, 5.0f, -35.0f);
	m_pShaderManager->setVec3Value("pointLights[4].ambient", 0.05f, 0.04f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[4].diffuse", 0.4f, 0.35f, 0.3f);
	m_pShaderManager->setVec3Value("pointLights[4].specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[4].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[5].position", 24.0f, 5.0f, -35.0f);
	m_pShaderManager->setVec3Value("pointLights[5].ambient", 0.05f, 0.04f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[5].diffuse", 0.4f, 0.35f, 0.3f);
	m_pShaderManager->setVec3Value("pointLights[5].specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[5].bActive", true);
	*/





	

	m_pShaderManager->setVec3Value("spotLight.ambient", 0.7f, 0.8f, 1.0f);
	m_pShaderManager->setVec3Value("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setVec3Value("spotLight.specular", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("spotLight.constant", 1.0f);  // sabit
	m_pShaderManager->setFloatValue("spotLight.linear", 0.15f);  // hizli zayiflama
	m_pShaderManager->setFloatValue("spotLight.quadratic", 0.09f);  // yavas zayiflama
	m_pShaderManager->setFloatValue("spotLight.cutOff", glm::cos(glm::radians(160.0f)));  // koni ic acisi
	m_pShaderManager->setFloatValue("spotLight.outerCutOff", glm::cos(glm::radians(10.0f)));  // dis sinir

	m_pShaderManager->setBoolValue("spotLight.bActive", true);  // isigi aktif







}




/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// define the materials for objects in the scene
	DefineObjectMaterials();
	// add and define the light sources for the scene
	SetupSceneLights();

	// load the textures for the 3D scene
	LoadSceneTextures();
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
}




void SceneManager::laptop(
	float width,
	float height,
	float depth,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos
)
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = xorient;
	float YrotationDegrees = yorient;
	float ZrotationDegrees = zorient;
	glm::vec3 positionXYZ;

	//*************************************** drawing screen ********************************//
	scaleXYZ = glm::vec3(width, height, depth);//determining size
		// setting up angles
	positionXYZ = glm::vec3(xpos, ypos-0.21, zpos-1.0f);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees - 30.0f,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1.0);//setting up color
	SetShaderTexture("plastic");
	SetShaderMaterial("mattePlastic");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawBoxMeshLines();
	*/
	//*************************************** drawing monitor ********************************//
	
	m_pShaderManager->setVec3Value("spotLight.position", glm::vec3(xpos, ypos + height / 30, zpos + depth / 2 + 0.002f));
	m_pShaderManager->setVec3Value("spotLight.direction", glm::vec3(0.0f, 0.0f, -0.75f));  


	scaleXYZ = glm::vec3((width/2)*0.96f, (depth/2 )* 0.96f, (height/2)*0.85f);//determining size
		// setting up angles
	positionXYZ = glm::vec3(xpos, (ypos+height/30)-0.30f, (zpos+ depth/2+0.001f)-1.0f);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees+60.0f,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1.0);//setting up color
	SetShaderTexture("screen");
	SetShaderMaterial("screen");  // Use the new screen material
	m_basicMeshes->DrawPlaneMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawPlaneMeshLines();
	*/

	//*************************************** drawing keyboard ********************************//
	scaleXYZ = glm::vec3(width, height, depth * 2);//determining size
		// setting up angles
	float XrotationDegreeskey = XrotationDegrees + 90.0f;
	positionXYZ = glm::vec3(xpos, ypos - ((height / 2) + depth / 10), zpos + ((height / 2) + depth / 10));//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegreeskey,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1.0);//setting up color
	SetShaderTexture("plastic");
	SetShaderMaterial("mattePlastic");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawBoxMeshLines();
	*/

	//*************************************** keys ********************************//
	scaleXYZ = glm::vec3(width/2,  depth , (height/2)*0.50);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos - ((height / 2) + depth / 10)+ depth+0.001f, zpos + ((height / 2) + depth / 10) - ((height / 2) * 0.50) / 2);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1.0);//setting up color
	SetShaderTexture("keyboard");
	SetShaderMaterial("non_reflective");
	m_basicMeshes->DrawPlaneMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawPlaneMeshLines();
	*/

	//*************************************** drawing left hinge ********************************//

	scaleXYZ = glm::vec3(height / 28, width / 14, height / 28);//determining size
		// setting up angles
	positionXYZ = glm::vec3(xpos - (width / 2) + 2 * (width / 14), (ypos - (height / 2) + (height / 14))-0.21f, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees + 90.0f,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1);//setting up color
	SetShaderTexture("plastic");
	SetShaderMaterial("metallicBlack");
	m_basicMeshes->DrawCylinderMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawCylinderMeshLines();
	*/

	//*************************************** drawing right hinge ********************************//

	scaleXYZ = glm::vec3(height / 28, width / 14, height / 28);//determining size
		// setting up angles
	positionXYZ = glm::vec3(xpos + (width / 2) - 2 * (width / 14), (ypos - (height / 2) + (height / 14))-0.21f, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees + 90.0f,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1);//setting up color
	SetShaderTexture("plastic");
	SetShaderMaterial("metallicBlack");
	m_basicMeshes->DrawCylinderMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawCylinderMeshLines();
	*/

	//*************************************** webcam ********************************//


	scaleXYZ = glm::vec3(height / 5, depth * 2, width / 80);//determining size
		// setting up angles
	positionXYZ = glm::vec3(xpos, ypos + (height / 2)-0.56f, (zpos - depth / 2)-2.0f);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees + 60.0f,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1.0);//setting up color

	SetShaderTexture("plastic");
	SetShaderMaterial("mattePlastic");
	m_basicMeshes->DrawCylinderMesh(false, true, true);//draw to the screen
	SetShaderColor(0, 0, 0, 1.0);//setting up color
	SetShaderMaterial("mirrorBlack");
	m_basicMeshes->DrawCylinderMesh(true, false, false);//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawCylinderMeshLines();
	*/
	//*************************************** touch pad ********************************//
	scaleXYZ = glm::vec3(width / 8, depth / 2, height / 10);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos - width / 2 + width / 3.8f, ypos - height / 2 + depth, zpos + (height * 2 / 3) + 3 * height / 20);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0, 0, 0, 1.0);//setting up color

	SetShaderMaterial("blackPlastic");
	m_basicMeshes->DrawPlaneMesh();//draw to the screen





	//*************************************** left button ********************************//


	scaleXYZ = glm::vec3(width / 8, depth / 2, height / 20);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos - width / 2 + width / 5, ypos - height / 2 + depth, zpos + (height * 2 / 3));//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0, 0, 0, 1.0);//setting up color

	SetShaderMaterial("blackPlastic");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawBoxMeshLines();
	*/
	//*************************************** right button ********************************//


	scaleXYZ = glm::vec3(width / 8, depth / 2, height / 20);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos - width / 2 + width / 5 + width / 8 + (width / 8) / 15, ypos - height / 2 + depth, zpos + (height * 2 / 3));//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0, 0, 0, 1.0);//setting up color
	SetShaderMaterial("blackPlastic");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawBoxMeshLines();
	*/

	//*************************************** track ball  ********************************//


	scaleXYZ = glm::vec3(depth, depth, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos - width / 2 + width / 5 + width / 16 + (width / 8) / 15, ypos - height / 2 + depth, zpos + (height * 2 / 3));//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//SetShaderColor(1, 1, 1, 1.0);//setting up color
	SetShaderTexture("rubber");
	SetShaderMaterial("rubber");
	m_basicMeshes->DrawHalfSphereMesh();//draw to the screen
	/*
	SetShaderColor(1, 0, 0, 1.0);
	m_basicMeshes->DrawHalfSphereMeshLines();
	*/

}


void SceneManager::bottle(
	float width,
	float height,
	float depth,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos
)
{


	glm::vec3 scaleXYZ;
	float XrotationDegrees = xorient;
	float YrotationDegrees = yorient;
	float ZrotationDegrees = zorient;
	glm::vec3 positionXYZ;




	//*************************************** liquid ********************************//

	scaleXYZ = glm::vec3(width - 0.3, height / 1.5, depth - 0.2);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, (ypos + height/1.5)+0.1 , zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.9f, 0.3f, 0.1f, 0.5f);
	SetShaderMaterial("whiskey");
	m_basicMeshes->DrawTaperedCylinderMesh();//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawTaperedCylinderMeshLines();//draw to the screen

	//*************************************** base  ********************************//
	
	scaleXYZ = glm::vec3(width, height, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos,ypos+height,zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.46, 0.63, 0.86, 0.2f);//setting up color
	SetShaderMaterial("glass");
	m_basicMeshes->DrawTaperedCylinderMesh();//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawTaperedCylinderMeshLines();//draw to the screen


	//*************************************** neck  ********************************//
	
	scaleXYZ = glm::vec3(width, height/4.2f, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos + height, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees * (-1.0f),
		ZrotationDegrees-180.0f,
		positionXYZ);
	SetShaderColor(0.6f, 0.8f, 1.0f, 0.15f);//setting up color
	SetShaderMaterial("glass");
	m_basicMeshes->DrawHalfSphereMesh();//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawHalfSphereMeshLines();//draw to the screen

	
	//*************************************** head   ********************************//


	scaleXYZ = glm::vec3(width/2.6, height/2, depth/2.6);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos +1.22f*height, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees * (-1.0f),
		ZrotationDegrees-180.0f,
		positionXYZ);
	SetShaderColor(0.6f, 0.8f, 1.0f, 0.15f);//setting up color
	SetShaderMaterial("glass");
	m_basicMeshes->DrawTaperedCylinderMesh();//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawTaperedCylinderMeshLines();//draw to the screen

	//*************************************** head 2  ********************************//


	scaleXYZ = glm::vec3(width / 5.2, height / 5, depth / 5.2);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos + 1.72f * height, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees * (-1.0f),
		ZrotationDegrees - 180.0f,
		positionXYZ);
	SetShaderColor(1, 0, 0, 1.0);//setting up color
	SetShaderMaterial("capMaterial");
	m_basicMeshes->DrawTaperedCylinderMesh();//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawTaperedCylinderMeshLines();//draw to the screen


	//*************************************** cap ********************************//


	scaleXYZ = glm::vec3(width / 6, width / 14, width / 6);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos + 1.92f * height, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(1, 0, 0, 1.0);//setting up color
	SetShaderMaterial("capMaterial");
	m_basicMeshes->DrawSphereMesh();//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawSphereMeshLines();//draw to the screen
	
	//*************************************** label ********************************//

	

}


void SceneManager::ashtray(
	float width,
	float height,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos
) 
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = xorient;
	float YrotationDegrees = yorient;
	float ZrotationDegrees = zorient;
	glm::vec3 positionXYZ;


	




	//*************************************** inside ********************************//
	
	float thickness = width / 12;
	scaleXYZ = glm::vec3(width - thickness, height - thickness, width - thickness);//determining size
// setting up angles
	positionXYZ = glm::vec3(xpos, ypos + thickness , zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);//setting up color
	SetShaderMaterial("ashTray");
	m_basicMeshes->DrawCylinderMesh(false, true, true);//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawCylinderMeshLines(false, true, true);//draw to the screen

	
	//*************************************** outside ********************************//
	
	scaleXYZ = glm::vec3(width, height , width);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);//setting up color
	SetShaderMaterial("ashTray");
	m_basicMeshes->DrawCylinderMesh(false,true,true);//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawCylinderMeshLines(false, true, true);//draw to the screen


	/**************************************  space between  cylinder  ******************/

	float numPlanes = 180; // Number of planes to cover the area
	float angleStep = 360.0f / numPlanes; // Angle step for placing the planes
	float planeWidth = thickness; // Width of the planes
	float planeHeight = height; // Height of the planes


	for (int i = 0; i < numPlanes; ++i) {
		float angle = glm::radians(i * angleStep);
		float xOffset = (width - thickness) * cos(angle); // X offset for placement
		float zOffset = (width - thickness) * sin(angle); // Z offset for placement

		scaleXYZ = glm::vec3(planeWidth, 0.02f, 0.02f); // Size of the plane
		positionXYZ = glm::vec3(xpos + xOffset, ypos+height, zpos + zOffset); // Position for the plane
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees+(i*-2.0f),
			ZrotationDegrees,
			positionXYZ);
		SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);//setting up color
		SetShaderMaterial("ashTray");
		m_basicMeshes->DrawPlaneMesh(); // Draw the plane
	}
	


}



void SceneManager::cigarette(
	float width,
	float height,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos)
{
	glm::mat4 rotationMatrix = glm::rotate(glm::mat4(1.0f), glm::radians(zorient), glm::vec3(0, 0, 1))
		* glm::rotate(glm::mat4(1.0f), glm::radians(yorient), glm::vec3(0, 1, 0))
		* glm::rotate(glm::mat4(1.0f), glm::radians(xorient), glm::vec3(1, 0, 0));

	glm::vec3 scaleXYZ;
	glm::vec3 basePosition = glm::vec3(xpos, ypos, zpos);
	glm::vec3 offset = glm::vec3(0.0f);

	// Ash
	scaleXYZ = glm::vec3(width, height, width);
	SetTransformations(scaleXYZ, xorient, yorient, zorient, basePosition + offset);
	SetShaderColor(0.45, 0.45, 0.44, 1.0f);
	SetShaderMaterial("ash");
	m_basicMeshes->DrawCylinderMesh();
	//SetShaderColor(1, 0, 0, 1.0);
	//m_basicMeshes->DrawCylinderMeshLines();

	// Cigarette body
	scaleXYZ = glm::vec3(width, height * 4.5f, width);
	offset += glm::vec3(rotationMatrix * glm::vec4(0, height, 0, 1));
	SetTransformations(scaleXYZ, xorient, yorient, zorient, basePosition + offset);
	SetShaderColor(1, 1, 1, 1.0f);
	SetShaderMaterial("paper");
	m_basicMeshes->DrawCylinderMesh();
	//SetShaderColor(0, 1, 0, 1.0);
	//m_basicMeshes->DrawCylinderMeshLines();

	// Filter
	scaleXYZ = glm::vec3(width, height * 1.5f, width);
	offset += glm::vec3(rotationMatrix * glm::vec4(0, height * 4.5f, 0, 1));
	SetTransformations(scaleXYZ, xorient, yorient, zorient, basePosition + offset);
	SetShaderColor(0.78, 0.48, 0.00, 1.0f);
	SetShaderMaterial("filter");
	m_basicMeshes->DrawCylinderMesh();
	//SetShaderColor(0, 0, 1, 1.0);
    //m_basicMeshes->DrawCylinderMeshLines();
}



void SceneManager::glass(
	float width,
	float height,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos) 
{

	glm::vec3 scaleXYZ;
	float XrotationDegrees = xorient;
	float YrotationDegrees = yorient;
	float ZrotationDegrees = zorient;
	glm::vec3 positionXYZ;


	float thickness = width / 60.0f;




	/****************** cubes ***********************************/

	scaleXYZ = glm::vec3(width / 1.7, width / 1.7, width / 1.7);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos + width / 3, ypos + height / 3 + width / 2, zpos - width / 3);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees + 18,
		YrotationDegrees + 75,
		ZrotationDegrees + 40,
		positionXYZ);
	SetShaderColor(0.38, 0.71, 0.81, 0.3);//setting up color
	SetShaderMaterial("iceCube");
	m_basicMeshes->DrawBoxMesh();//draw to the screen

	positionXYZ = glm::vec3(xpos - width / 3, ypos + height / 1.8 + width / 3, zpos + width / 3);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees + 32,
		YrotationDegrees + 25,
		ZrotationDegrees - 20,
		positionXYZ);
	SetShaderColor(0.38, 0.71, 0.81, 0.3);//setting up color
	SetShaderMaterial("iceCube");
	m_basicMeshes->DrawBoxMesh();//draw to the screen


	/****************** drink ***********************************/

	scaleXYZ = glm::vec3(width - thickness, height - height / 4, width - thickness);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.9f, 0.3f, 0.1f, 0.5f);//setting up color
	SetShaderMaterial("whiskey");
	m_basicMeshes->DrawCylinderMesh();//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawCylinderMeshLines();//draw to the screen





	/****************** base ***********************************/

	scaleXYZ = glm::vec3(width, height/4, width);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.46, 0.63, 0.86, 0.2f);//setting up color
	SetShaderMaterial("glass");
	m_basicMeshes->DrawCylinderMesh();//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawCylinderMeshLines();//draw to the screen

	/****************** outside ***********************************/
	scaleXYZ = glm::vec3(width, height, width);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos+height/4, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.46, 0.63, 0.86, 0.2f);//setting up color
	SetShaderMaterial("glass");
	m_basicMeshes->DrawCylinderMesh(false, true, true);//draw to the screen
	//SetShaderColor(1, 0, 0, 1.0);//setting up color
	//m_basicMeshes->DrawCylinderMeshLines(false, true, true);//draw to the screen

	/****************** inside ***********************************/

	scaleXYZ = glm::vec3(width-thickness, height + height / 4, width-thickness);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.46, 0.63, 0.86, 0.2f);//setting up color
	SetShaderMaterial("glass");
	m_basicMeshes->DrawCylinderMesh(false, true, true);//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawCylinderMeshLines(false, true, true);//draw to the screen


	/****************** between ***********************************/

	float numPlanes = 180; // Number of planes to cover the area
	float angleStep = 360.0f / numPlanes; // Angle step for placing the planes
	float planeWidth = thickness; // Width of the planes
	float planeHeight = height; // Height of the planes


	for (int i = 0; i < numPlanes; ++i) {
		float angle = glm::radians(i * angleStep);
		float xOffset = (width - thickness) * cos(angle); // X offset for placement
		float zOffset = (width - thickness) * sin(angle); // Z offset for placement

		scaleXYZ = glm::vec3(planeWidth, 0.02f, 0.02f); // Size of the plane
		positionXYZ = glm::vec3(xpos + xOffset, ypos + (5* height)/4, zpos + zOffset); // Position for the plane
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees + (i * -2.0f),
			ZrotationDegrees,
			positionXYZ);
		SetShaderColor(0.46, 0.63, 0.86, 0.2f);//setting up color
		m_basicMeshes->DrawPlaneMesh(); // Draw the plane
	}


}

void SceneManager::sigarettebox(
	float width,
	float height,
	float depth,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos)
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = xorient;
	float YrotationDegrees = yorient;
	float ZrotationDegrees = zorient;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(width, height, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(1, 1, 1, 1);//setting up color
	SetShaderTexture("cigarette");
	SetShaderMaterial("cigarettePaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->top);
	SetShaderColor(0.79, 0.79, 0.79, 1.0f);//setting up color
	SetShaderMaterial("cigarettePaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->bottom);
	SetShaderColor(1, 1, 1, 1);//setting up color
	SetShaderMaterial("cigarettePaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->front);
	SetShaderColor(1, 0, 0, 1.0f);//setting up color
	SetShaderMaterial("cigarettePaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->back);
	SetShaderColor(1, 1, 1, 1.0f);//setting up color
	SetShaderMaterial("cigarettePaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->left);
	SetShaderColor(1, 1, 1, 1.0f);//setting up color
	SetShaderMaterial("cigarettePaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->right);


	//*********************************** plane ***************************************//

	scaleXYZ = glm::vec3(width/2.4, height, height/2);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos+width/1.88+0.03, ypos, zpos+0.1728);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees +90,
		YrotationDegrees +90,
		ZrotationDegrees ,
		positionXYZ);
	SetShaderColor(1.0f, 0.0f, 0.0f, 1.0f);//setting up color
	m_basicMeshes->DrawPlaneMesh();


	scaleXYZ = glm::vec3(width / 2.4, height, height / 2);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos + width *0.3355 , ypos, zpos - 0.2917);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees + 90,
		YrotationDegrees + 90,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(1.0f, 0.0f, 0.0f, 1.0f);//setting up color

	m_basicMeshes->DrawPlaneMesh();
	

}




void SceneManager::matches(
	float width,
	float height,
	float depth,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos)
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = xorient;
	float YrotationDegrees = yorient;
	float ZrotationDegrees = zorient;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(width, height, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	SetShaderColor(0.94, 0.87, 0.78, 1);//setting up color
	SetShaderMaterial("yellowPaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->top);
	SetShaderColor(0.94, 0.87, 0.78, 1.0f);//setting up color
	SetShaderMaterial("yellowPaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->bottom);
	SetShaderColor(1, 1, 1, 1);//setting up color
	SetShaderMaterial("yellowPaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->left);
	SetShaderColor(0.94, 0.87, 0.78, 1.0f);//setting up color
	SetShaderMaterial("yellowPaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->right);
	SetShaderColor(0.37, 0.15, 0.07, 1.0f);//setting up color
	SetShaderMaterial("yellowPaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->front);
	SetShaderColor(0.37, 0.15, 0.07, 1.0f);//setting up color
	SetShaderMaterial("yellowPaper");
	m_basicMeshes->DrawBoxMeshSide(m_basicMeshes->back);



	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);//setting up color
	//SetShaderMaterial("paper");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawBoxMeshLines();//draw to the screen

}



void SceneManager::book(
	float width,
	float height,
	float depth,
	float xorient,
	float yorient,
	float zorient,
	float xpos,
	float ypos,
	float zpos)
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = xorient;
	float YrotationDegrees = yorient;
	float ZrotationDegrees = zorient;
	glm::vec3 positionXYZ;


	//bottomcover
	ypos += height / 2;
	scaleXYZ = glm::vec3(width, height, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);//setting up color
	SetShaderMaterial("bookCover");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawBoxMeshLines();//draw to the screen

	//papers
	float thickness = height*3;

	scaleXYZ = glm::vec3(width-height, thickness, depth-height);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos-height/2, ypos+height/2+thickness/2, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.86f, 0.86f, 0.86f, 1.0f);//setting up color
	SetShaderMaterial("paper");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawBoxMeshLines();//draw to the screen

	//topcover

	scaleXYZ = glm::vec3(width, height, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos, ypos+height+thickness, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);//setting up color
	SetShaderMaterial("bookCover");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawBoxMeshLines();//draw to the screen


	//sirt

	scaleXYZ = glm::vec3(height, height + height + thickness, depth);//determining size
	// setting up angles
	positionXYZ = glm::vec3(xpos-width/2, ypos+ (height + thickness)/2, zpos);//determining position
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);//setting up color
	SetShaderMaterial("bookCover");
	m_basicMeshes->DrawBoxMesh();//draw to the screen
	//SetShaderColor(0, 1, 0, 1.0);//setting up color
	//m_basicMeshes->DrawBoxMeshLines();//draw to the screen

}





/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 1, 1, 1);

	SetShaderMaterial("blackboard");
	SetShaderTexture("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	laptop(7.08f, 4.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 2.2f, 0.0f);
	bottle(1.4f, 2.4f, 0.8f, 0.0f, -5.0f, 180.0f, -5.4f, 0.0f, -1.6f);
	ashtray(0.8f, 0.4f, 0.0f, 0.0f, 0.0f, -4.7f, 0.0f, 4.0f);
	cigarette(0.04f, 0.15f, 20.0f, 0.0f, -60.0f, -4.65f, 0.12f, 4.0f);
	glass(0.6f, 0.8f, 0.0f, 0.0f, 0.0f, -5.7f, 0.2f, 3.0f);
	sigarettebox(0.48f, 0.14f, 0.864f, 0.0f, -75.0f, 0.0f, -4.2f, 0.07f, 5.3f);
	matches(0.810f, 0.13f, 0.480f, 0.0f, 20.0f, 0.0f, -2.0f, 0.065f, 4.5f);
	book(1.6f, 0.025f, 2.29f, 0.0f, 0.0f, 0.0f, 5.9f, 0.0f, 1.0f);

	
}
